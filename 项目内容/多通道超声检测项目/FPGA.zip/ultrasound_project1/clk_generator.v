//============================================================
// 模块名 : AD9670_CLK_GEN（与 daima.docx 中原模块名完全一致）
// 目标   : Cyclone IV EP4CE6E22C8N
// 功能   : 50MHz 输入 → 40MHz LVDS 差分时钟输出（AD9670 采样时钟）
// 核心修正：1. 关闭 ALTPLL 显式复位端口；2. 用内部逻辑保障复位功能
//============================================================
module AD9670_CLK_GEN(
    input  wire          sys_clk_50mhz,    // 输入：50MHz 主时钟（全局时钟）
    input  wire          sys_rst_n,        // 输入：系统复位（低有效，异步）
    output reg           clk_40mhz_p,      // 输出：40MHz 差分时钟+（LVDS）
    output reg           clk_40mhz_n,      // 输出：40MHz 差分时钟-（LVDS）
    output reg           clk_locked        // 输出：PLL 锁定标志（高有效）
);

// -------------------------- 内部信号定义（适配无显式复位端口） --------------------------
wire                  clk_40mhz;        // 中间：ALTPLL 输出的 40MHz 单端时钟
wire                  pll_locked_raw;   // 中间：ALTPLL 原始锁定信号（未处理复位）
reg                   pll_locked;       // 中间：复位处理后的锁定信号（确保复位时为0）

// -------------------------- Intel Cyclone IV ALTPLL 原语（无显式复位端口） --------------------------
// 关键修正：1. 删除所有复位相关参数（rst_mode）；2. 不连接显式复位端口（rst/aclr）
ALTPLL #(
    // 1. 输入时钟参数（与 50MHz 完全匹配）
    .inclk0_input_frequency(20),          // 50MHz 对应时钟周期：20ns（单位：ns）
    .number_of_clock_outputs(1),          // 输出时钟数量：1 路（仅需 40MHz）
    // 2. 40MHz 输出时钟参数（50*4/5=40MHz，与 daima.docx 原需求一致）
    .clk0_multiply_by(4),                 // 倍频系数：4
    .clk0_divide_by(5),                   // 分频系数：5
    .clk0_duty_cycle(50),                 // 占空比：50%（LVDS 时钟强制要求）
    .clk0_phase_shift(0),                 // 相位偏移：0°（无需时序偏移）
    // 3. 工作模式参数（删除复位相关参数，避免端口冲突）
    .operation_mode("NORMAL"),            // 正常工作模式（非零延迟）
    .pll_type("AUTO"),                    // 自动适配 Cyclone IV PLL 硬件
    .lpm_type("altera_pll"),              // 固定宏功能类型（Quartus 识别必需）
    .lpm_hint("CBX_MODULE_PREFIX=u_pll_40mhz")
) u_altera_pll_40mhz (
    // 核心修正：不连接任何显式复位端口（无 rst/aclr），避免“端口不存在”错误
    .inclk({1'b0,sys_clk_50mhz}),              // 输入时钟：对应 inclk[0]，语法合规
    .clk({5'b00000, clk_40mhz}),                    // 输出时钟：对应 clk[0]，语法合规
    .locked(pll_locked_raw)               // 锁定信号：原始输出（后续处理复位）
);

// -------------------------- 复位逻辑处理（替代显式复位端口） --------------------------
// 功能：系统复位时，强制 PLL 锁定信号为 0（模拟复位效果，与原逻辑一致）
always @(posedge sys_clk_50mhz or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        pll_locked <= 1'b0;
    end else begin
        pll_locked <= pll_locked_raw;     // 复位释放后，传递原始锁定信号
    end
end

// -------------------------- 差分时钟生成（完全复用 daima.docx 原逻辑） --------------------------
always @(posedge clk_40mhz or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        clk_40mhz_p <= 1'b0;
        clk_40mhz_n <= 1'b1;
        clk_locked  <= 1'b0;
    end else begin
        clk_40mhz_p <= clk_40mhz;        // 差分正端：接 40MHz 单端时钟
        clk_40mhz_n <= ~clk_40mhz;       // 差分负端：接时钟反相（LVDS 标准）
        clk_locked  <= pll_locked;       // 传递处理后的锁定信号（原逻辑不变）
    end
end

endmodule