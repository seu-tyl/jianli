//============================================================
// 模块名 : ultrasound_tx.v
// 功能 : MAX4940发射控制 + MAX4936 SPI选通（4通道切换）
// 核心逻辑：通道切换时先关当前→更新选通→开下一通道（避免多通道导通）
//============================================================
module ultrasound_system (
    input  wire          clk,              // 输入：50MHz时钟（与顶层同步）
    input  wire          sys_rst_n,        // 输入：系统复位（低有效）
    input  wire          start_en,         // 输入：启动使能（AD就绪后为1）
    output reg           P1, P2, P3, P4,   // 输出：发射正端（单端）
    output reg           N1, N2, N3, N4,   // 输出：发射负端（单端）
    output reg           max_clr,          // 输出：MAX4936清除（高有效）
    output reg           max_le,           // 输出：MAX4936锁存（低脉冲有效）
    output reg           max_din,          // 输出：MAX4936串行输入（SPI）
    input  wire          max_dout,         // 输入：MAX4936串行输出（未使用）
    output reg           max_clk,          // 输出：MAX4936 SPI时钟（10MHz）
    output reg [2:0]     curr_channel,     // 输出：当前通道标记（0~7）
    output reg           enable_tx,        // 输出：发射使能（高有效）
    output reg           updating          // 输出：通道切换中标志（高有效）
);

// -------------------------- 参数定义（可配置） --------------------------
parameter MAIN_CLK_HZ     = 50_000_000;   // 主时钟频率（50MHz）
parameter STATE_PERIOD_US = 50_000;       // 每通道持续时间（50ms，可调整）
parameter SPI_FREQ_HZ     = 10_000_000;   // MAX4936 SPI时钟频率（10MHz）

// 衍生参数（无需修改）
localparam CYCLES_PER_STATE = MAIN_CLK_HZ / (1_000_000 / STATE_PERIOD_US); // 每通道周期数
localparam SPI_DIV          = MAIN_CLK_HZ / (SPI_FREQ_HZ * 2);             // SPI时钟分频系数

// -------------------------- 内部寄存器 --------------------------
reg [31:0] cnt_state = 0;                 // 通道周期计数器（0~CYCLES_PER_STATE-1）
reg [7:0]  shift_reg = 8'd0;              // MAX4936 SPI数据移位寄存器
reg [3:0]  bit_idx   = 0;                 // SPI bit计数（0~7，共8位）
reg [15:0] spi_div   = 0;                 // SPI时钟分频计数器
reg        spi_clk   = 0;                 // 内部SPI时钟（10MHz）
reg        spi_clk_prev = 0;              // 上一拍SPI时钟（用于边沿检测）

// -------------------------- SPI时钟生成（10MHz，占空比50%） --------------------------
always @(posedge clk) begin
    if (!start_en) begin // AD未就绪：关闭SPI时钟
        spi_div <= 16'd0;
        spi_clk <= 1'b0;
    end else if (spi_div >= SPI_DIV - 1) begin // 分频计数满：翻转时钟
        spi_div <= 16'd0;
        spi_clk <= ~spi_clk;
    end else begin
        spi_div <= spi_div + 1'b1;
    end
    max_clk <= spi_clk; // 输出SPI时钟到MAX4936
end

// -------------------------- 通道周期计数（AD就绪后运行） --------------------------
always @(posedge clk) begin
    if (!sys_rst_n || !start_en) begin // 复位或未启动：计数器清零
        cnt_state <= 32'd0;
        curr_channel <= 3'd0;
    end else if (cnt_state >= CYCLES_PER_STATE - 1) begin // 周期满：切换通道
        cnt_state <= 32'd0;
        curr_channel <= (curr_channel == 3'd7) ? 3'd0 : curr_channel + 1'b1; // 0~7循环
    end else begin
        cnt_state <= cnt_state + 1'b1;
    end
end

// -------------------------- MAX4936 SPI选通逻辑（通道切换控制） --------------------------
always @(posedge clk) begin
    spi_clk_prev <= spi_clk; // 保存上一拍SPI时钟，用于上升沿检测

    if (!sys_rst_n || !start_en) begin // 复位或未启动：初始化
        updating <= 1'b0;
        enable_tx <= 1'b0;
        shift_reg <= 8'd0;
        bit_idx <= 4'd0;
        max_le <= 1'b1; // 锁存无效（高电平）
        max_clr <= 1'b0; // 清除无效（低电平）
    end else begin
        // 1. 通道切换标志与发射使能控制
        if (curr_channel == 3'd0 && cnt_state == 32'd1) begin
            updating <= 1'b1; // 通道0启动时：开始SPI更新
        end else if (bit_idx == 4'd0 && !spi_clk && updating) begin
            updating <= 1'b0; // SPI更新完成：清除切换标志
            enable_tx <= 1'b1; // 允许发射
        end else if (cnt_state >= CYCLES_PER_STATE - 1000) begin
            enable_tx <= 1'b0; // 通道周期结束前1000周期：关闭发射（提前关断）
        end

        // 2. SPI数据发送（8位，MSB先行）
        if (updating) begin
            if (bit_idx == 4'd0 && !spi_clk) begin // SPI低电平：加载选通控制字
                shift_reg <= 8'd0; // 初始化为0（所有通道关闭）
                case (curr_channel) // 对应当前通道，置位选通位（MAX4936规格书）
                    3'd0,3'd4: shift_reg[0] <= 1'b1; // 通道1（正/反相）
                    3'd1,3'd5: shift_reg[1] <= 1'b1; // 通道2（正/反相）
                    3'd2,3'd6: shift_reg[2] <= 1'b1; // 通道3（正/反相）
                    3'd3,3'd7: shift_reg[3] <= 1'b1; // 通道4（正/反相）
                    default: ;
                endcase
                max_le <= 1'b1; // 锁存无效
                max_clr <= 1'b0; // 清除无效
            end

            // SPI上升沿：发送1位数据（移位寄存器左移）
            if (spi_clk_prev == 1'b0 && spi_clk == 1'b1) begin
                max_din <= shift_reg[7]; // 发送MSB
                shift_reg <= {shift_reg[6:0], 1'b0}; // 移位寄存器左移
                bit_idx <= bit_idx + 1'b1;

                if (bit_idx == 4'd7) begin // 8位发送完成
                    bit_idx <= 4'd0;
                    max_le <= 1'b0; // 拉低锁存：更新选通配置
                end
            end
        end else begin
            if (max_le == 1'b0) max_le <= 1'b1; // 锁存恢复高电平
            max_din <= 1'b0; // 无发送时：DIN置0
        end
    end
end

// -------------------------- 发射控制（与选通同步，防止P/N同时导通） --------------------------
always @(posedge clk) begin
    if (!sys_rst_n || !start_en || !enable_tx || updating) begin
        // 复位/未启动/未使能/切换中：关闭所有发射通道
        P1 <= 1'b0; P2 <= 1'b0; P3 <= 1'b0; P4 <= 1'b0;
        N1 <= 1'b0; N2 <= 1'b0; N3 <= 1'b0; N4 <= 1'b0;
    end else begin
        // 默认关闭所有通道
        P1 <= 1'b0; P2 <= 1'b0; P3 <= 1'b0; P4 <= 1'b0;
        N1 <= 1'b0; N2 <= 1'b0; N3 <= 1'b0; N4 <= 1'b0;

        // 根据当前通道，开启对应P/N（正相/反相发射）
        case (curr_channel)
            3'd0: begin P1 <= 1'b1; N1 <= 1'b0; end // 通道1正相
            3'd1: begin P2 <= 1'b1; N2 <= 1'b0; end // 通道2正相
            3'd2: begin P3 <= 1'b1; N3 <= 1'b0; end // 通道3正相
            3'd3: begin P4 <= 1'b1; N4 <= 1'b0; end // 通道4正相
            3'd4: begin P1 <= 1'b0; N1 <= 1'b1; end // 通道1反相
            3'd5: begin P2 <= 1'b0; N2 <= 1'b1; end // 通道2反相
            3'd6: begin P3 <= 1'b0; N3 <= 1'b1; end // 通道3反相
            3'd7: begin P4 <= 1'b0; N4 <= 1'b1; end // 通道4反相
            default: ;
        endcase
    end

    // 硬件保护：强制关闭同时导通的P/N（避免短路）
    if (P1 && N1) N1 <= 1'b0;
    if (P2 && N2) N2 <= 1'b0;
    if (P3 && N3) N3 <= 1'b0;
    if (P4 && N4) N4 <= 1'b0;
end

endmodule