module ad9670_lvds_data_receiver(
    input  wire          sys_rst_n,        // 系统复位（低有效）
    input  wire          dco_p,            // 数据时钟+（LVDS）
    input  wire          dco_n,            // 数据时钟-（LVDS）
    input  wire          fco_p,            // 帧时钟+（LVDS）
    input  wire          fco_n,            // 帧时钟-（LVDS）
    input  wire [7:0]    dout_p,           // 8通道数据+（LVDS，每通道1位）
    input  wire [7:0]    dout_n,           // 8通道数据-（LVDS，每通道1位）
    output reg [111:0]   adc_data_ch,      // 8通道AD数据（14位/通道，总112位）
    output reg           data_valid        // 数据有效标志
);

// -------------------------- 内部信号定义 --------------------------
// LVDS时钟与帧信号差分转单端
wire                  dco;               // 数据时钟（单端）
wire                  fco;               // 帧时钟（单端）
wire [7:0]            dout;              // 8通道数据（单端，每通道1位）

// 同步复位信号
reg                   rst_sync;

// 数据移位寄存器（每通道14位，串行转并行）
reg [13:0]            ch0_shift;
reg [13:0]            ch1_shift;
reg [13:0]            ch2_shift;
reg [13:0]            ch3_shift;
reg [13:0]            ch4_shift;
reg [13:0]            ch5_shift;
reg [13:0]            ch6_shift;
reg [13:0]            ch7_shift;

// 位计数（14位数据计数）
reg [3:0]             bit_cnt;           // 0~13（14位）

// 帧时钟边沿检测
reg                   fco_d1, fco_d2;
wire                  fco_posedge;

// -------------------------- 差分信号转单端（Cyclone IV 标准配置：删除非法参数） --------------------------
// 关键修正：
// 1. 移除所有参数（Cyclone IV 的 ALT_INBUF_DIFF 不支持 DIFF_TERM/LOW_POWER，默认配置满足需求）
// 2. 保留核心端口：I（正端）、IBAR（负端）、O（单端输出），确保连接正确

// 1. 数据时钟（LVDS转单端：仅保留基础端口，无额外参数）
ALT_INBUF_DIFF
u_ibufds_dco (
    .I(dco_p),                // 差分输入正端
    .IBAR(dco_n),             // 差分输入负端（Cyclone IV 原语标准端口名）
    .O(dco)                   // 单端输出
);

// 2. 帧时钟（LVDS转单端：仅保留基础端口，无额外参数）
ALT_INBUF_DIFF
u_ibufds_fco (
    .I(fco_p),
    .IBAR(fco_n),
    .O(fco)
);

// 3. 8通道数据（LVDS转单端：仅保留基础端口，无额外参数）
genvar i;
generate
    for(i=0; i<8; i=i+1) begin : data_lvds_conv
        ALT_INBUF_DIFF
        u_ibufds_data (
            .I(dout_p[i]),
            .IBAR(dout_n[i]),
            .O(dout[i])        // 每通道1位单端数据
        );
    end
endgenerate

// -------------------------- 复位同步 --------------------------
always @(posedge dco or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        rst_sync <= 1'b1;
    end else begin
        rst_sync <= 1'b0;
    end
end

// -------------------------- 帧时钟边沿检测 --------------------------
always @(posedge dco or posedge rst_sync) begin
    if(rst_sync) begin
        fco_d1 <= 1'b0;
        fco_d2 <= 1'b0;
    end else begin
        fco_d1 <= fco;
        fco_d2 <= fco_d1;
    end
end
assign fco_posedge = fco_d1 & ~fco_d2;  // 帧时钟上升沿：新数据帧开始

// -------------------------- 数据串并转换（14位/通道） --------------------------
always @(posedge dco or posedge rst_sync) begin
    if(rst_sync) begin
        // 复位时清空移位寄存器和标志
        ch0_shift <= 14'd0;
        ch1_shift <= 14'd0;
        ch2_shift <= 14'd0;
        ch3_shift <= 14'd0;
        ch4_shift <= 14'd0;
        ch5_shift <= 14'd0;
        ch6_shift <= 14'd0;
        ch7_shift <= 14'd0;
        bit_cnt <= 4'd0;
        data_valid <= 1'b0;
        adc_data_ch <= 112'd0;
    end else begin
        if(fco_posedge) begin
            // 帧时钟上升沿：开始新的14位数据接收
            bit_cnt <= 4'd0;
            data_valid <= 1'b0;
        end else begin
            if(bit_cnt < 4'd13) begin
                // 接收第0~12位：左移移位寄存器，新位补到最低位
                ch0_shift <= {ch0_shift[12:0], dout[0]};
                ch1_shift <= {ch1_shift[12:0], dout[1]};
                ch2_shift <= {ch2_shift[12:0], dout[2]};
                ch3_shift <= {ch3_shift[12:0], dout[3]};
                ch4_shift <= {ch4_shift[12:0], dout[4]};
                ch5_shift <= {ch5_shift[12:0], dout[5]};
                ch6_shift <= {ch6_shift[12:0], dout[6]};
                ch7_shift <= {ch7_shift[12:0], dout[7]};
                bit_cnt <= bit_cnt + 1'b1;
            end else begin
                // 接收第13位（最后一位），完成14位数据
                ch0_shift <= {ch0_shift[12:0], dout[0]};
                ch1_shift <= {ch1_shift[12:0], dout[1]};
                ch2_shift <= {ch2_shift[12:0], dout[2]};
                ch3_shift <= {ch3_shift[12:0], dout[3]};
                ch4_shift <= {ch4_shift[12:0], dout[4]};
                ch5_shift <= {ch5_shift[12:0], dout[5]};
                ch6_shift <= {ch6_shift[12:0], dout[6]};
                ch7_shift <= {ch7_shift[12:0], dout[7]};
                bit_cnt <= 4'd0;
                
                // 拼接8通道数据，输出并置位有效标志
                adc_data_ch <= {
                    ch7_shift,  // 通道7：111~98
                    ch6_shift,  // 通道6：97~84
                    ch5_shift,  // 通道5：83~70
                    ch4_shift,  // 通道4：69~56
                    ch3_shift,  // 通道3：55~42
                    ch2_shift,  // 通道2：41~28
                    ch1_shift,  // 通道1：27~14
                    ch0_shift   // 通道0：13~0
                };
                data_valid <= 1'b1;  // 数据有效
            end
        end
    end
end

endmodule