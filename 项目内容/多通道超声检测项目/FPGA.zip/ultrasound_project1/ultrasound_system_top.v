//============================================================
// 模块名 : ad9670_test.v
// 目标芯片 : Cyclone IV EP4CE6E22C8N
// 功能 : 仅测试AD9670采集功能（移除超声发射部分）
// 接口说明：
// - 系统时钟：50MHz（低电平复位）
// - AD接口：AD9670 LVDS差分信号（40MSPS采样）
// - 输出：112位AD数据（8通道×14位）+ 有效标志
//============================================================
module ultrasound_system (
    // 系统时钟与复位
    input  wire          sys_clk_50mhz,    // 输入：50MHz主时钟（全局时钟）
    input  wire          sys_rst_n,        // 输入：系统复位（低有效，异步）

    // AD9670采集接口（LVDS差分信号）
    output reg           ad9670_sclk,      // 输出：AD9670 SPI时钟（25MHz）
    inout  wire          ad9670_sdio,      // 双向：AD9670 SPI数据（三态）
    output reg           ad9670_csb,       // 输出：AD9670片选（低有效）
    output reg           ad9670_pdwn,      // 输出：AD9670断电控制（0=正常）
    output reg           ad9670_stby,      // 输出：AD9670待机控制（0=正常）
    output reg           ad9670_tx_trig_p, // 输出：AD9670触发+（LVDS差分）
    output reg           ad9670_tx_trig_n, // 输出：AD9670触发-（LVDS差分）
    output reg           ad9670_clk_p,     // 输出：AD9670采样时钟+（40MSPS，LVDS）
    output reg           ad9670_clk_n,     // 输出：AD9670采样时钟-（LVDS）
    output reg [4:0]     ad9670_addr,      // 输出：AD9670地址（单芯片=0）
    input  wire [7:0]    ad9670_dout_p,    // 输入：AD9670 8通道数据+（LVDS）
    input  wire [7:0]    ad9670_dout_n,    // 输入：AD9670 8通道数据-（LVDS）
    input  wire          ad9670_dco_p,     // 输入：AD9670数据时钟+（LVDS）
    input  wire          ad9670_dco_n,     // 输入：AD9670数据时钟-（LVDS）
    input  wire          ad9670_fco_p,     // 输入：AD9670帧时钟+（LVDS）
    input  wire          ad9670_fco_n,     // 输入：AD9670帧时钟-（LVDS）

    // 系统输出（采集数据）
    output reg [111:0]   ad_data_ch,       // 输出：8通道AD数据（14位/通道，共112位）
    output reg           ad_data_valid,    // 输出：数据有效标志（高有效）
    output reg [2:0]     curr_channel      // 输出：当前采集通道（0~7，来自AD帧同步）
);

// -------------------------- 中间线网信号 --------------------------
// AD9670相关中间信号（wire类型，连接子模块）
wire                  ad_sclk;           // SPI时钟
wire                  ad_csb;            // 片选信号
wire                  ad_pdwn;           // 断电控制
wire                  ad_stby;           // 待机控制
wire                  ad_clk_p;          // 采样时钟+
wire                  ad_clk_n;          // 采样时钟-
wire [4:0]            ad_addr;           // 地址信号
wire [111:0]          ad_rx_data;        // 采集数据
wire                  ad_rx_valid;       // 数据有效标志
wire                  ad_config_done;    // 配置完成标志
wire                  ad_clk_locked;     // 时钟锁定标志
wire                  ad_spi_sdio_en;    // SPI输出使能
wire [2:0]            ad_frame_channel;  // AD帧同步解析的通道号（新增：从AD帧信号提取）

// 时序同步信号
reg                   ad_ready;          // AD就绪（配置完成+时钟锁定）

// -------------------------- 子模块例化 --------------------------
// AD9670采集核心模块（保留并完善通道解析）
ad9670_core u_ad9670_core(
    .sys_clk_50mhz    (sys_clk_50mhz),
    .sys_rst_n        (sys_rst_n),
    .spi_sclk         (ad_sclk),
    .spi_sdio         (ad9670_sdio),
    .spi_sdio_en      (ad_spi_sdio_en),
    .spi_csb          (ad_csb),
    .pdwn             (ad_pdwn),
    .stby             (ad_stby),
    .tx_trig_p        (ad9670_tx_trig_p),  // 连接触发信号
    .tx_trig_n        (ad9670_tx_trig_n),  // 连接触发信号
    .clk_p            (ad_clk_p),
    .clk_n            (ad_clk_n),
    .addr             (ad_addr),
    .dout_p           (ad9670_dout_p),
    .dout_n           (ad9670_dout_n),
    .dco_p            (ad9670_dco_p),
    .dco_n            (ad9670_dco_n),
    .fco_p            (ad9670_fco_p),
    .fco_n            (ad9670_fco_n),
    .adc_data_ch      (ad_rx_data),
    .data_valid       (ad_rx_valid),
    .config_done      (ad_config_done),
    .clk_locked       (ad_clk_locked),
    .frame_channel    (ad_frame_channel)   // 新增：输出当前帧通道号
);

// -------------------------- 信号传递逻辑（reg <- wire） --------------------------
// AD9670相关信号传递
always @(posedge sys_clk_50mhz or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        ad9670_sclk <= 1'b0;
        ad9670_csb <= 1'b1;
        ad9670_pdwn <= 1'b1;
        ad9670_stby <= 1'b1;
        ad9670_clk_p <= 1'b0;
        ad9670_clk_n <= 1'b1;
        ad9670_addr <= 5'b00000;
    end else begin
        ad9670_sclk <= ad_sclk;
        ad9670_csb <= ad_csb;
        ad9670_pdwn <= ad_pdwn;
        ad9670_stby <= ad_stby;
        ad9670_clk_p <= ad_clk_p;
        ad9670_clk_n <= ad_clk_n;
        ad9670_addr <= ad_addr;
    end
end

// -------------------------- 时序同步逻辑 --------------------------
// 1. AD就绪判断（配置完成 + 时钟锁定）
always @(posedge sys_clk_50mhz or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        ad_ready <= 1'b0;
    end else begin
        ad_ready <= ad_config_done & ad_clk_locked;
    end
end

// 2. 生成AD9670触发信号（AD就绪后持续触发，确保采集启动）
always @(posedge sys_clk_50mhz or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        ad9670_tx_trig_p <= 1'b0;
        ad9670_tx_trig_n <= 1'b1;
    end else if(ad_ready) begin
        // AD就绪后，触发信号持续有效（差分对：P=1，N=0）
        ad9670_tx_trig_p <= 1'b1;
        ad9670_tx_trig_n <= 1'b0;
    end else begin
        ad9670_tx_trig_p <= 1'b0;
        ad9670_tx_trig_n <= 1'b1;
    end
end

// 3. 系统输出：AD数据 + 通道标记
always @(posedge sys_clk_50mhz or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        ad_data_ch <= 112'd0;
        ad_data_valid <= 1'b0;
        curr_channel <= 3'd0;
    end else begin
        ad_data_ch <= ad_rx_data;         // 传递AD采集数据
        ad_data_valid <= ad_rx_valid;     // 传递数据有效标志
        curr_channel <= ad_frame_channel; // 传递AD帧解析的通道号
    end
end

endmodule