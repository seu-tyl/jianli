`timescale 1ns / 1ps

module ultrasound_system(
    // 系统接口
    input           sys_clk_50mhz,      // 50MHz 系统时钟
    input           sys_rst_n,          // 低电平复位
    
    // UART 输出接口
    output          uart_tx,            // 串行输出到PC
    
    // AD9670 控制接口
    output          ad9670_csb,         // 片选 (低有效)
    output          ad9670_sclk,        // SPI 时钟
    inout           ad9670_sdio,        // 双向数据线
    output          ad9670_stby,        // 待机控制（可选）
    
    // AD9670 时钟输入
    input           ad9670_clk_p,       // 差分时钟正端
    input           ad9670_clk_n,       // 差分时钟负端
    
    // AD9670 数据输出（LVDS）
    input   [7:0]   ad9670_dout_p,      // LVDS 正端数据 (8通道)
    input   [7:0]   ad9670_dout_n,      // LVDS 负端数据 (8通道)
    
    // AD9670 DCO 时钟输出
    input           ad9670_dco_p,       // DCO 正端
    input           ad9670_dco_n,       // DCO 负端
    
    // AD9670 FCO 时钟输出
    input           ad9670_fco_p,       // FCO 正端
    input           ad9670_fco_n,       // FCO 负端
    
    // AD9670 触发输入
    input           ad9670_tx_trig_p,   // 触发正端
    input           ad9670_tx_trig_n    // 触发负端
);

//=================== 内部信号定义 ===================//
// 通用同步复位
wire rst_sync;

// SPI 配置相关信号
reg [1:0] clk_cnt;                      // SCLK 分频计数器
reg [4:0] bit_cnt;                      // 数据位计数器
reg [23:0] curr_data;                   // 当前要发送的24位配置数据
reg spi_sdio_oe;                        // 输出使能：1=输出, 0=输入
reg spi_sdio_out;                       // 输出数据
wire spi_sdio_in = ad9670_sdio;         // 输入数据（本例未使用）
reg spi_sclk_reg;
reg spi_csb_reg;
reg [2:0] curr_state;
localparam 
    S_IDLE = 3'd0,
    S_START = 3'd1,
    S_WRITE = 3'd2,
    S_CSB_HIGH = 3'd3;

// 差分信号转单端
wire [7:0] dout;
wire dco;
wire fco;
wire tx_trig;

// LVDS 串并转换
reg [13:0] ch_shift[7:0];               // 8个14位移位寄存器
reg [3:0] bit_cnt_lvds;
reg [13:0] ch0_data, ch1_data, ch2_data, ch3_data;
reg [13:0] ch4_data, ch5_data, ch6_data, ch7_data;
reg data_valid;                         // 并行数据有效标志

// 数据缓冲
reg [13:0] ch_data[7:0];

// UART 发送控制
reg uart_tx_en;
reg [7:0] uart_din;
wire uart_tx_done;
reg [1:0] hex_cnt;                      // 十六进制字符计数 (0-3)
reg [3:0] state;                        // 数据发送状态机
localparam 
    S_WAIT = 4'd0,
    S_CH0  = 4'd1,
    S_CH1  = 4'd2,
    S_CH2  = 4'd3,
    S_CH3  = 4'd4,
    S_CH4  = 4'd5,
    S_CH5  = 4'd6,
    S_CH6  = 4'd7,
    S_CH7  = 4'd8,
    S_CR   = 4'd9;                      // 发送回车
reg [13:0] curr_data_uart;              // 当前要发送的通道数据

//=================== 三态控制 ===================//
assign ad9670_sdio = (spi_sdio_oe) ? spi_sdio_out : 1'bz;

//=================== 模块实例化 ===================//
// 同步复位生成
sync_reset u_sync_reset (
    .clk(sys_clk_50mhz),
    .rst_n(sys_rst_n),
    .rst_sync(rst_sync)
);

// UART 发送模块
uart_tx #(.CLK_FREQ(50_000_000), .BAUD_RATE(115200)) 
u_uart_tx (
    .clk(sys_clk_50mhz),
    .rst(rst_sync),
    .tx_en(uart_tx_en),
    .din(uart_din),
    .tx(uart_tx),
    .tx_done(uart_tx_done)
);

// DCO 时钟差分转单端
diff_buf dco_buf_inst (
    .a(ad9670_dco_p),
    .b(ad9670_dco_n),
    .z(dco)
);

// FCO 时钟差分转单端
diff_buf fco_buf_inst (
    .a(ad9670_fco_p),
    .b(ad9670_fco_n),
    .z(fco)
);

// TX_TRIG 差分转单端
diff_buf trig_buf_inst (
    .a(ad9670_tx_trig_p),
    .b(ad9670_tx_trigen),
    .z(tx_trig)
);

// CLK_IN 差分转单端（可选）
diff_buf clk_buf_inst (
    .a(ad9670_clk_p),
    .b(ad9670_clk_n),
    .z(clk_in)
);

// DOUT 数据差分转单端
genvar i;
generate
    for (i = 0; i < 8; i = i + 1) begin : diff_buf_gen
        diff_buf data_buf_inst (
            .a(ad9670_dout_p[i]),
            .b(ad9670_dout_n[i]),
            .z(dout[i])
        );
    end
endgenerate

//=================== 功能实现 ===================//

//---------- 1. SPI 配置状态机 ----------
always @(posedge sys_clk_50mhz or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        curr_state <= S_IDLE;
        spi_csb_reg <= 1'b1;
        spi_sclk_reg <= 1'b0;
        spi_sdio_oe <= 1'b0;
        spi_sdio_out <= 1'b0;
        clk_cnt <= 2'd0;
        bit_cnt <= 5'd0;
        curr_data <= 24'h000000;
    end else begin
        case (curr_state)
            S_IDLE: begin
                curr_state <= S_START;
                spi_csb_reg <= 1'b0;
                curr_data <= 24'h000001; // 示例配置
                bit_cnt <= 5'd0;
                clk_cnt <= 2'd0;
                spi_sdio_oe <= 1'b1;     // 使能输出
                spi_sdio_out <= 1'b0;
            end
            
            S_START: begin
                curr_state <= S_WRITE;
                clk_cnt <= 2'd0;
            end
            
            S_WRITE: begin
                clk_cnt <= clk_cnt + 1'b1;
                case (clk_cnt)
                    2'd0: begin
                        spi_sclk_reg <= 1'b0;
                        spi_sdio_out <= curr_data[23 - bit_cnt];  // ✅ 过程赋值
                    end
                    2'd1: begin
                        spi_sclk_reg <= 1'b1;
                    end
                    2'd2: begin
                        spi_sclk_reg <= 1'b0;
                        bit_cnt <= bit_cnt + 1'b1;
                        if (bit_cnt == 5'd23) begin
                            bit_cnt <= 5'd0;
                            curr_state <= S_CSB_HIGH;
                            spi_sdio_oe <= 1'b0;  // 发送完成，关闭输出
                        end
                        clk_cnt <= 2'd0;
                    end
                    default: begin
                        clk_cnt <= 2'd0;
                    end
                endcase
            end
            
            S_CSB_HIGH: begin
                spi_csb_reg <= 1'b1;
                curr_state <= S_IDLE;
            end
            
            default: curr_state <= S_IDLE;
        endcase
    end
end

// 输出赋值
assign ad9670_csb = spi_csb_reg;
assign ad9670_sclk = spi_sclk_reg;
assign ad9670_stby = 1'b0; // 可根据需要启用待机模式

//---------- 2. LVDS 串并转换 ----------
always @(posedge dco or posedge rst_sync) begin
    integer j;
    if (rst_sync) begin
        for (j=0; j<8; j=j+1) begin
            ch_shift[j] <= 14'd0;
        end
        bit_cnt_lvds <= 4'd0;
        data_valid <= 1'b0;
        ch0_data <= 14'd0;
        ch1_data <= 14'd0;
        ch2_data <= 14'd0;
        ch3_data <= 14'd0;
        ch4_data <= 14'd0;
        ch5_data <= 14'd0;
        ch6_data <= 14'd0;
        ch7_data <= 14'd0;
    end else begin
        data_valid <= 1'b0;
        
        for (j=0; j<8; j=j+1) begin
            ch_shift[j] <= {ch_shift[j][12:0], dout[j]};
        end
        
        if (bit_cnt_lvds == 4'd13) begin
            ch0_data <= ch_shift[0];
            ch1_data <= ch_shift[1];
            ch2_data <= ch_shift[2];
            ch3_data <= ch_shift[3];
            ch4_data <= ch_shift[4];
            ch5_data <= ch_shift[5];
            ch6_data <= ch_shift[6];
            ch7_data <= ch_shift[7];
            data_valid <= 1'b1;
            bit_cnt_lvds <= 4'd0;
        end else begin
            bit_cnt_lvds <= bit_cnt_lvds + 1'b1;
        end
    end
end

//---------- 3. 数据缓冲 ----------
always @(posedge sys_clk_50mhz or posedge rst_sync) begin
    integer k;
    if (rst_sync) begin
        for (k = 0; k < 8; k = k + 1) begin
            ch_data[k] <= 14'd0;
        end
    end else if (data_valid) begin
        ch_data[0] <= ch0_data;
        ch_data[1] <= ch1_data;
        ch_data[2] <= ch2_data;
        ch_data[3] <= ch3_data;
        ch_data[4] <= ch4_data;
        ch_data[5] <= ch5_data;
        ch_data[6] <= ch6_data;
        ch_data[7] <= ch7_data;
    end
end

//---------- 4. 数据格式转换与UART发送 ----------
function [7:0] hex_to_ascii;
    input [13:0] data;
    input [1:0]  idx;
    reg [3:0] hex_val;
    begin
        case(idx)
            2'd0: hex_val = data[13:10];
            2'd1: hex_val = data[9:6];  
            2'd2: hex_val = data[5:2];  
            2'd3: hex_val = data[3:0];
        endcase
        hex_to_ascii = (hex_val < 4'd10) ? (hex_val + 8'h30) : (hex_val + 8'h37);
    end
endfunction

always @(posedge sys_clk_50mhz or posedge rst_sync) begin
    if (rst_sync) begin
        state <= S_WAIT;
        uart_tx_en <= 1'b0;
        hex_cnt <= 2'd0;
        curr_data_uart <= 14'd0;
    end else begin
        uart_tx_en <= 1'b0;
        
        case (state)
            S_WAIT: begin
                if (data_valid) begin
                    curr_data_uart <= ch_data[0];
                    hex_cnt <= 2'd0;
                    uart_din <= hex_to_ascii(curr_data_uart, 2'd0);
                    uart_tx_en <= 1'b1;
                    state <= S_CH0;
                end
            end
            
            S_CH0, S_CH1, S_CH2, S_CH3, S_CH4, S_CH5, S_CH6, S_CH7: begin
                if (uart_tx_done) begin
                    if (hex_cnt < 2'd3) begin
                        hex_cnt <= hex_cnt + 1'b1;
                        uart_din <= hex_to_ascii(curr_data_uart, hex_cnt + 1'b1);
                        uart_tx_en <= 1'b1;
                    end else begin
                        hex_cnt <= 2'd0;
                        if (state < S_CH7) begin
                            state <= state + 1'b1;
                            curr_data_uart <= ch_data[state - S_CH0 + 1];
                            uart_din <= 8'h2C; // 逗号
                            uart_tx_en <= 1'b1;
                        end else begin
                            uart_din <= 8'h0D; // 回车
                            uart_tx_en <= 1'b1;
                            state <= S_CR;
                        end
                    end
                end else if (!uart_tx_en) begin
                    uart_din <= hex_to_ascii(curr_data_uart, hex_cnt);
                    uart_tx_en <= 1'b1;
                end
            end
            
            S_CR: begin
                if (uart_tx_done) begin
                    state <= S_WAIT;
                end
            end
            
            default: state <= S_WAIT;
        endcase
    end
end

endmodule

//=================== 辅助模块 ===================//

// 差分输入缓冲模块 (简化模型)
module diff_buf (
    input a,
    input b,
    output z
);
    assign z = a & ~b; // 简化逻辑，实际由硬件处理
endmodule

// 同步复位电路
module sync_reset (
    input clk,
    input rst_n,
    output reg rst_sync
);
    reg [1:0] sync_reg;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sync_reg <= 2'b00;
            rst_sync <= 1'b1;
        end else begin
            sync_reg <= {sync_reg[0], 1'b1};
            rst_sync <= sync_reg[1];
        end
    end
endmodule

// UART 发送模块
module uart_tx #(
    parameter CLK_FREQ = 50_000_000,
    parameter BAUD_RATE = 115200
) (
    input clk,
    input rst,
    input tx_en,
    input [7:0] din,
    output reg tx,
    output reg tx_done
);
    localparam CNT_MAX = CLK_FREQ / BAUD_RATE - 1;

    reg [15:0] baud_cnt;
    reg [3:0] bit_cnt;
    reg tx_busy;
    reg [7:0] shift_reg;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            baud_cnt <= 16'd0;
            bit_cnt <= 4'd0;
            tx_busy <= 1'b0;
            tx <= 1'b1;
            tx_done <= 1'b0;
            shift_reg <= 8'd0;
        end else begin
            tx_done <= 1'b0;

            if (tx_en && !tx_busy) begin
                tx_busy <= 1'b1;
                shift_reg <= din;
                bit_cnt <= 4'd0;
                baud_cnt <= 16'd0;
                tx <= 1'b0;
            end else if (tx_busy) begin
                if (baud_cnt < CNT_MAX) begin
                    baud_cnt <= baud_cnt + 1'b1;
                end else begin
                    baud_cnt <= 16'd0;
                    if (bit_cnt < 4'd10) begin
                        case (bit_cnt)
                            4'd0:  tx <= shift_reg[0];
                            4'd1:  tx <= shift_reg[1];
                            4'd2:  tx <= shift_reg[2];
                            4'd3:  tx <= shift_reg[3];
                            4'd4:  tx <= shift_reg[4];
                            4'd5:  tx <= shift_reg[5];
                            4'd6:  tx <= shift_reg[6];
                            4'd7:  tx <= shift_reg[7];
                            4'd8:  tx <= 1'b1; // 停止位
                            4'd9:  tx <= 1'b1; // 额外停止位
                        endcase
                        bit_cnt <= bit_cnt + 1'b1;
                    end else begin
                        tx_busy <= 1'b0;
                        tx_done <= 1'b1;
                    end
                end
            end
        end
    end
endmodule