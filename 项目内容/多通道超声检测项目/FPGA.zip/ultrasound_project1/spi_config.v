module ad9670_spi_config(
    input  wire          sys_clk_50mhz,
    input  wire          sys_rst_n,
    output reg           spi_sclk,
    inout  wire          spi_sdio,        // 双向口
    output reg           spi_sdio_en,     // 新增：输出使能（1=写数据，0=高阻）
    output reg           spi_csb,
    output reg           config_done
);

// -------------------------- 1. SPI时序参数（规格书Table 25） --------------------------
localparam SPI_CLK_PERIOD = 40;  // 25MHz（满足t_CLK≥40ns最小周期）
localparam SPI_CLK_HALF   = SPI_CLK_PERIOD / 2;
localparam t_DS = 2;  // 数据建立时间≥12.5ns（2个50MHz周期=40ns，满足要求）
localparam t_DH = 1;  // 数据保持时间≥5ns

// -------------------------- 2. AD9670寄存器配置表（规格书推荐启动序列Table 26） --------------------------
// 格式：{寄存器地址[15:0], 写入数据[7:0]}（24位/项，无多余1'b1，消除截断）
reg [23:0] reg_config[14:0];
initial begin
    // ① SPI复位（0x000）：Bit2=1，复位后自动清0
    reg_config[0]  = {16'h0000, 8'h3C};
    // ② 速度模式（0x002）：Mode I（40MSPS，Bits[5:4]=00）
    reg_config[1]  = {16'h0002, 8'h00};
    // ③ 更新速度模式（0x0FF）：触发模式生效
    reg_config[2]  = {16'h00FF, 8'h01};
    // ④ 通道选择（0x004/0x005）：选中所有8通道
    reg_config[3]  = {16'h0004, 8'h0F};
    reg_config[4]  = {16'h0005, 8'h3F};
    // ⑤ 数字解调配置（0x113）：bypass RF decimator，使能HPF
    reg_config[5]  = {16'h0113, 8'h03};
    // ⑥ GAIN配置（0x011）：LNA=21.6dB、PGA=24dB、VGA衰减=0dB（总45.6dB）
    reg_config[6]  = {16'h0011, 8'hF6};  // 0xF6=1111 0110
    // ⑦ Profile配置（0xF00~0xF07，连续运行模式）
    reg_config[7]  = {16'h0F00, 8'hFF};
    reg_config[8]  = {16'h0F01, 8'h7F};
    reg_config[9]  = {16'h0F02, 8'h00};
    reg_config[10] = {16'h0F03, 8'h80};
    reg_config[11] = {16'h0F04, 8'h0C};
    reg_config[12] = {16'h0F05, 8'h00};
    // ⑧ 加载Profile 0（0x10C）
    reg_config[13] = {16'h010C, 8'h00};
    // ⑨ 启动TGC模式（0x008）：000=芯片运行（TGC模式）
    reg_config[14] = {16'h0008, 8'h00};
end

// -------------------------- 3. SPI状态机（消除锁存器+截断警告） --------------------------
localparam S_IDLE    = 0;
localparam S_CSB_LOW = 1;
localparam S_WRITE   = 2;
localparam S_CSB_HIGH= 3;
localparam S_DONE    = 4;

reg [2:0] curr_state;
reg [3:0] reg_cnt;    // 0~14（15个寄存器）
reg [4:0] bit_cnt;    // 0~23（24位/寄存器）
reg [1:0] clk_cnt;    // 时钟周期计数
reg [23:0] curr_data; // 当前写入数据
reg spi_sdio_out;     // 修正为1位（原8位，消除截断警告）：SPI输出数据缓存

// 状态跳转+信号赋值（所有路径覆盖spi_csb，消除锁存器）
always @(posedge sys_clk_50mhz or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        // 复位：所有信号明确初始化，无不定态
        curr_state <= S_IDLE;
        reg_cnt <= 4'd0;
        bit_cnt <= 5'd0;
        clk_cnt <= 2'd0;
        curr_data <= 24'd0;
        spi_sdio_en <= 1'b0;  // 初始高阻
        spi_sdio_out <= 1'b0;
        config_done <= 1'b0;
        spi_sclk <= 1'b0;
        spi_csb <= 1'b1;      // 复位时片选高（未选中芯片）
    end else begin
        case(curr_state)
            S_IDLE: begin
                // 空闲状态：片选高，准备配置
                spi_csb <= 1'b1;
                spi_sclk <= 1'b0;
                if(sys_rst_n) begin  // 复位释放后启动配置
                    curr_state <= S_CSB_LOW;
                    curr_data <= reg_config[reg_cnt];
                end
            end

            S_CSB_LOW: begin
                // 拉低片选，选中芯片（延时稳定）
                spi_csb <= 1'b0;
                clk_cnt <= clk_cnt + 1'b1;
                if(clk_cnt == 2'd3) begin  // 延时4个时钟周期，确保稳定
                    clk_cnt <= 2'd0;
                    curr_state <= S_WRITE;
                    spi_sdio_en <= 1'b1;    // 进入写模式，使能输出
                end
            end

            S_WRITE: begin
                // 逐位写24位数据（MSB先写，规格书默认）
                spi_csb <= 1'b0;  // 写数据期间保持片选低
                clk_cnt <= clk_cnt + 1'b1;

                if(clk_cnt == 2'd0) begin  // SCLK低电平：准备数据（无截断）
                    spi_sclk <= 1'b0;
                    spi_sdio_out <= curr_data[23 - bit_cnt];  // 1位→1位，匹配宽度
                end else if(clk_cnt == 2'd1) begin  // SCLK高电平：数据有效
                    spi_sclk <= 1'b1;
                    bit_cnt <= bit_cnt + 1'b1;

                    if(bit_cnt == 5'd23) begin  // 24位写完，切换到结束状态
                        bit_cnt <= 5'd0;
                        curr_state <= S_CSB_HIGH;
                        spi_sdio_en <= 1'b0;    // 关闭输出，进入高阻
                    end
                end
            end

            S_CSB_HIGH: begin
                // 拉高片选，结束当前寄存器配置
                spi_csb <= 1'b1;
                clk_cnt <= clk_cnt + 1'b1;
                if(clk_cnt == 2'd3) begin  // 延时稳定后切换
                    clk_cnt <= 2'd0;
                    reg_cnt <= reg_cnt + 1'b1;

                    if(reg_cnt == 4'd14) begin  // 所有15个寄存器配置完成
                        reg_cnt <= 4'd0;
                        curr_state <= S_DONE;
                        config_done <= 1'b1;     // 置位配置完成标志
                    end else begin  // 配置下一个寄存器
                        curr_data <= reg_config[reg_cnt];
                        curr_state <= S_CSB_LOW;
                    end
                end
            end

            S_DONE: begin
                // 配置完成：保持片选高，标志稳定
                spi_csb <= 1'b1;
                spi_sclk <= 1'b0;
                curr_state <= S_DONE;  // 稳定在完成状态
            end

            default: begin
                // 异常状态：复位到空闲，片选高（避免未知路径）
                curr_state <= S_IDLE;
                spi_csb <= 1'b1;
                spi_sclk <= 1'b0;
                spi_sdio_en <= 1'b0;
            end
        endcase
    end
end

// 三态双向口实现（修正10137错误：连续赋值，不直接驱动inout）
assign spi_sdio = spi_sdio_en ? spi_sdio_out : 1'bz;

endmodule