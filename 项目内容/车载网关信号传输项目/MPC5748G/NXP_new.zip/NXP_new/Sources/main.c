/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2019 NXP
 * All rights reserved.
 *
 * FreeRTOS移植版本 - 最终完整版
 * 功能：1. CAN2→SPI联动 2. SPI→CAN1 CAN FD转发(64字节) 3. 完整软件看门狗(监控所有任务)
 * 看门狗：监控8个任务，超时5秒打印日志并重置，优先级最高
 */
#include "Cpu.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdarg.h>
#include "clockMan1.h"
#include "canCom1.h"     // CAN FD模式
#include "canCom2.h"     // 标准CAN模式
#include "dspi1.h"       // SPI
#include "dmaController1.h"
#include "pin_mux.h"
#include "uart_pal1.h"
#if CPU_INIT_CONFIG
#include "Init_Config.h"
#endif
/* FreeRTOS头文件 */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"
/* 系统复位函数 */
void NVIC_SystemReset(void)
{
    const uint32_t AIRCR_VECTKEY = (0x5FAUL << 16);
    volatile uint32_t *AIRCR = (volatile uint32_t *)0xE000ED0CUL;
    uint32_t reg = *AIRCR;
    reg = (reg & 0x700U) | AIRCR_VECTKEY | (1UL << 2);
    *AIRCR = reg;
    for (;;) { ; }
}
/******************************************************************************
 * 硬件配置定义（含CAN FD+看门狗宏）
 ******************************************************************************/
#define LED_PORT        PTA
#define LED0            10U
#define LED1            7U
#define LED2            4U
/* UART配置 */
#define TIMEOUT         1000UL
#define BUFFER_SIZE     128UL
#define UART_SEND_BUF   64UL
/* CAN配置（CAN FD核心宏） */
#define CAN_LED_CTRL_ID_LED0_ON  0x123UL
#define CAN_LED_CTRL_ID_LED1_ON  0x456UL
#define CAN_LED_CTRL_DATA_TOGGLE 0x01U
#define CAN_LED_CTRL_DATA_OFF    0x02U
#define CAN_LED_CTRL_DATA_ON     0x03U
#define CANFD_MAX_DLEN      64U        // CAN FD最大数据长度
#define CANFD_TX_FORWARD_ID 0x300UL    // SPI转发CAN FD的固定ID
#define CAN1_TX_MAILBOX     1UL        // CAN1发送邮箱
/* SPI配置（64字节收发） */
#define SPI_TRANSFER_TIMEOUT     1000U
#define SPI_FRAME_SIZE           64U
#define SPI_CAN_PACKAGE_SIZE     13U
#define SPI_TRANSFER_INTERVAL_MS 10U
/* 软件看门狗配置（原版参数，新增CAN1_Tx监控项） */
#define WATCHDOG_TIMEOUT_MS    5000U    // 任务超时时间：5秒
#define WATCHDOG_CHECK_MS      1000U    // 看门狗检查周期：1秒
typedef enum {
    WD_CAN_INIT = 0,
    WD_SPI_INIT,
    WD_UART,
    WD_LED,
    WD_CAN2_RX,
    WD_SPI_TX,
    WD_SPI_RX,
    WD_CAN1_TX,  // 新增：监控CAN1 CAN FD发送任务
    WD_COUNT     // 总任务数：8个
} WatchdogId_t;
/******************************************************************************
 * FreeRTOS对象定义（含CAN1+看门狗）
 ******************************************************************************/
QueueHandle_t xCanRxQueue;        /* CAN2接收队列 */
QueueHandle_t xSpiTxQueue;        /* SPI发送队列 */
QueueHandle_t xSpiRxQueue;        /* SPI接收队列 */
QueueHandle_t xCan1TxQueue;       /* CAN1 CAN FD发送队列 */
SemaphoreHandle_t xUartMutex;     /* UART互斥锁 */
SemaphoreHandle_t xCanMutex;      /* CAN2互斥锁 */
SemaphoreHandle_t xSpiMutex;      /* SPI互斥锁 */
SemaphoreHandle_t xCan1Mutex;     /* CAN1互斥锁 */
TaskHandle_t xCanInitTaskHandle;
TaskHandle_t xSpiInitTaskHandle;
TaskHandle_t xUartTaskHandle;
TaskHandle_t xLedTaskHandle;
TaskHandle_t xCan2RxTaskHandle;   /* CAN2接收任务 */
TaskHandle_t xSpiTxTaskHandle;    /* SPI发送任务 */
TaskHandle_t xSpiRxTaskHandle;    /* SPI接收任务 */
TaskHandle_t xCan1TxTaskHandle;   /* CAN1 CAN FD发送任务 */
EventGroupHandle_t xSystemEvents;
/* 看门狗全局变量（原版） */
static volatile TickType_t g_watchdog_last_tick[WD_COUNT];
/* 事件标志位定义 */
#define EVENT_BUTTON1_PRESSED    (1 << 1)
#define EVENT_UART_TX_READY      (1 << 2)
#define EVENT_INIT_COMPLETE      (1 << 3)
#define EVENT_CAN_DATA_RECEIVED  (1 << 4)
#define EVENT_SPI_RX_DATA        (1 << 5)
#define EVENT_FUNC_STARTED       (1 << 6)
#define EVENT_SPI2CAN_READY      (1 << 7)  // SPI转CAN就绪事件
/******************************************************************************
 * 全局变量（保留SPI缓冲区）
 ******************************************************************************/
uint8_t uartRxBuffer[BUFFER_SIZE];
uint8_t bufferIdx = 0;
volatile bool rxComplete = false;
uint8_t spi_tx_buffer[SPI_FRAME_SIZE];  /* SPI发送缓冲区 */
uint8_t spi_rx_buffer[SPI_FRAME_SIZE];  /* SPI接收缓冲区 */
/* SPI接收数据结构体（含时间戳） */
typedef struct {
    uint32_t msgId;
    uint8_t data[SPI_FRAME_SIZE];
    uint8_t dataLen;
    uint32_t sendTimestamp;
    uint32_t recvTimestamp;
} SpiRxData;
/* 外部声明DSPI1状态变量 */
extern dspi_state_t dspi1State;
/******************************************************************************
 * 函数声明（含看门狗+CAN1+SPI联动）
 ******************************************************************************/
void RTOS_Objects_Init_Base(void);
void RTOS_Objects_Init_Func(void);
void CAN_Init_Task(void *pvParameters);
void SPI_Init_Task(void *pvParameters);
void UART_Task(void *pvParameters);
void LED_Task(void *pvParameters);
void uartRxCallback(void *driverState, uart_event_t event, void *userData);
void GPIO_Init(void);
void Board_Init(void);
void uart_log(const char *fmt, ...);
void CANCOM1_Init(void);
void CANCOM2_Init(void);
void DSPI_Init(void);
/* 核心功能函数 */
void CAN2_Rx_Task(void *pvParameters);
void SPI_Tx_Task(void *pvParameters);
void SPI_Rx_Task(void *pvParameters);
void CAN1_Tx_Task(void *pvParameters);
void UART_PrintCANMsg(uint32_t msgId, uint8_t *data, uint8_t len);
void LED_ControlByCAN(uint32_t msgId, uint8_t *data, uint8_t dataLen);
void SPI_SendCANMessage(uint32_t msgId, uint8_t *data, uint8_t dataLen);
void ProcessAndForwardSPI2CANData(SpiRxData *spiRxData);
/* 看门狗函数（原版完整实现） */
void Watchdog_Pet(WatchdogId_t id);
static void Watchdog_Task(void *pvParameters);
/* 日志宏 */
#define LOG(...) uart_log(__VA_ARGS__)
/******************************************************************************
 * UART接收回调函数（保留）
 ******************************************************************************/
void uartRxCallback(void *driverState, uart_event_t event, void *userData)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    (void)driverState;
    (void)userData;
    if (event == UART_EVENT_RX_FULL)
    {
        if (uartRxBuffer[bufferIdx] == '\n' ||
            uartRxBuffer[bufferIdx] == '\r' ||
            bufferIdx == (BUFFER_SIZE - 1))
        {
            rxComplete = true;
            xEventGroupSetBitsFromISR(xSystemEvents, EVENT_UART_TX_READY,
                                      &xHigherPriorityTaskWoken);
        }
        else
        {
            bufferIdx++;
            UART_ReceiveData(&uart_pal1_instance, &uartRxBuffer[bufferIdx], 1U);
        }
    }
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}
/******************************************************************************
 * CAN初始化任务（含看门狗喂狗）
 ******************************************************************************/
void CAN_Init_Task(void *pvParameters)
{
    (void)pvParameters;
    LOG("开始CAN初始化...\r\n");
    /* 1. 初始化CANCOM2（标准CAN模式） */
    LOG("正在初始化CANCOM2（标准CAN模式）...\r\n");
    status_t status_can2 = FLEXCAN_DRV_Init(INST_CANCOM2, &canCom2_State, &canCom2_InitConfig0);
    if (status_can2 == STATUS_SUCCESS) {
        LOG("CANCOM2 初始化成功\r\n");
    } else {
        LOG("CANCOM2 初始化失败 (状态: %d)\r\n", status_can2);
    }
    vTaskDelay(pdMS_TO_TICKS(100));
    /* 2. 初始化CANCOM1（CAN FD模式） */
    LOG("正在初始化CANCOM1（CAN FD模式）...\r\n");
    status_t status_can1 = FLEXCAN_DRV_Init(INST_CANCOM1, &canCom1_State, &canCom1_InitConfig0);
    if (status_can1 == STATUS_SUCCESS) {
        LOG("CANCOM1 初始化成功\r\n");
    } else {
        LOG("CANCOM1 初始化失败 (状态: %d)\r\n", status_can1);
    }
    LOG("================================================\r\n");
    LOG("CAN初始化完成: CANCOM2(%s), CANCOM1(%s)\r\n",
        status_can2 == STATUS_SUCCESS ? "成功" : "失败",
        status_can1 == STATUS_SUCCESS ? "成功" : "失败");
    LOG("即将启动所有CAN-SPI联动功能...\r\n");
    LOG("================================================\r\n");
    xEventGroupSetBits(xSystemEvents, EVENT_INIT_COMPLETE);
    RTOS_Objects_Init_Func();
    /* 任务循环：喂看门狗（WD_CAN_INIT） */
    for(;;)
    {
        Watchdog_Pet(WD_CAN_INIT);
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
}
/******************************************************************************
 * SPI初始化任务（含看门狗喂狗）
 ******************************************************************************/
void SPI_Init_Task(void *pvParameters)
{
    (void)pvParameters;
    LOG("开始SPI初始化...\r\n");
    DSPI_Init();
    /* 任务循环：喂看门狗（WD_SPI_INIT） */
    for(;;)
    {
        Watchdog_Pet(WD_SPI_INIT);
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
}
/******************************************************************************
 * CAN2接收任务（含看门狗喂狗）
 ******************************************************************************/
void CAN2_Rx_Task(void *pvParameters)
{
    flexcan_msgbuff_t recvMsg;
    (void)pvParameters;
    xEventGroupWaitBits(xSystemEvents, EVENT_FUNC_STARTED, pdFALSE, pdFALSE, portMAX_DELAY);
    flexcan_data_info_t std_rx_info = {
        .data_length = 8U,
        .msg_id_type = FLEXCAN_MSG_ID_STD,
        .enable_brs = false,
        .fd_enable = false,
        .fd_padding = 0U
    };
    FLEXCAN_DRV_ConfigRxMb(INST_CANCOM2, 0, &std_rx_info, 0);
    FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM2, FLEXCAN_MSG_ID_STD, 0U);
    LOG("CAN2接收任务启动成功 - 已准备接收CAN消息\r\n");
    /* 任务循环：喂看门狗（WD_CAN2_RX） */
    for(;;)
    {
        if (FLEXCAN_DRV_Receive(INST_CANCOM2, 0, &recvMsg) == STATUS_SUCCESS && recvMsg.dataLen > 0)
        {
            UART_PrintCANMsg(recvMsg.msgId, recvMsg.data, recvMsg.dataLen);
            LED_ControlByCAN(recvMsg.msgId, recvMsg.data, recvMsg.dataLen);
            SPI_SendCANMessage(recvMsg.msgId, recvMsg.data, recvMsg.dataLen);
            if(xQueueSend(xCanRxQueue, &recvMsg, portMAX_DELAY) == pdPASS)
            {
                xEventGroupSetBits(xSystemEvents, EVENT_CAN_DATA_RECEIVED);
            }
            memset(&recvMsg, 0, sizeof(recvMsg));
        }
        Watchdog_Pet(WD_CAN2_RX);
        vTaskDelay(pdMS_TO_TICKS(2));
    }
}
/******************************************************************************
 * SPI发送任务（含看门狗喂狗）
 ******************************************************************************/
void SPI_Tx_Task(void *pvParameters)
{
    flexcan_msgbuff_t spiMsg;
    (void)pvParameters;
    xEventGroupWaitBits(xSystemEvents, EVENT_FUNC_STARTED, pdFALSE, pdFALSE, portMAX_DELAY);
    LOG("SPI发送任务启动成功 - 已准备发送64字节数据\r\n");
    vTaskDelay(pdMS_TO_TICKS(100));
    /* 任务循环：喂看门狗（WD_SPI_TX） */
    for(;;)
    {
        if(xQueueReceive(xSpiTxQueue, &spiMsg, pdMS_TO_TICKS(SPI_TRANSFER_INTERVAL_MS)) == pdTRUE)
        {
            if(xSemaphoreTake(xSpiMutex, pdMS_TO_TICKS(50)) == pdTRUE)
            {
                uint32_t sendTime = (uint32_t)(xTaskGetTickCount() * portTICK_PERIOD_MS);
                uint8_t *ptr = spi_tx_buffer;
                *(uint32_t *)ptr = spiMsg.msgId;
                ptr += 4;
                *ptr = spiMsg.dataLen;
                ptr += 1;
                memcpy(ptr, spiMsg.data, spiMsg.dataLen);
                if (spiMsg.dataLen < 8)
                {
                    memset(ptr + spiMsg.dataLen, 0, 8 - spiMsg.dataLen);
                }
                memset(spi_tx_buffer + SPI_CAN_PACKAGE_SIZE, 0, SPI_FRAME_SIZE - SPI_CAN_PACKAGE_SIZE);

                status_t spi_status = DSPI_MasterTransferBlocking(
                    INST_DSPI1,
                    spi_tx_buffer,
                    spi_rx_buffer,
                    SPI_FRAME_SIZE,
                    SPI_TRANSFER_TIMEOUT
                );
                if (spi_status != STATUS_SUCCESS)
                {
                    LOG("SPI Transfer Failed! Status: %d\r\n", spi_status);
                }
                else
                {
                    LOG("SPI Transfer Success! 64Byte Tx Completed | 发送CAN ID: 0x%03lX\r\n", spiMsg.msgId);
                    SpiRxData rxData;
                    rxData.msgId = spiMsg.msgId;
                    memcpy(rxData.data, spi_rx_buffer, SPI_FRAME_SIZE);
                    rxData.dataLen = SPI_FRAME_SIZE;
                    rxData.sendTimestamp = sendTime;
                    if (xQueueSend(xSpiRxQueue, &rxData, 0) == pdPASS)
                    {
                        xEventGroupSetBits(xSystemEvents, EVENT_SPI_RX_DATA);
                    }
                    PINS_DRV_TogglePins(LED_PORT, (1 << LED1));
                }
                xSemaphoreGive(xSpiMutex);
            }
        }
        Watchdog_Pet(WD_SPI_TX);
        vTaskDelay(pdMS_TO_TICKS(2));
    }
}
/******************************************************************************
 * SPI接收任务（含看门狗喂狗+SPI→CAN1转发）
 ******************************************************************************/
void SPI_Rx_Task(void *pvParameters)
{
    SpiRxData rxData;
    EventBits_t uxBits;
    (void)pvParameters;
    xEventGroupWaitBits(xSystemEvents, EVENT_FUNC_STARTED, pdFALSE, pdFALSE, portMAX_DELAY);
    LOG("SPI接收任务启动成功 - 等待从机响应数据...\r\n");
    /* 任务循环：喂看门狗（WD_SPI_RX） */
    for(;;)
    {
        uxBits = xEventGroupWaitBits(
            xSystemEvents,
            EVENT_SPI_RX_DATA,
            pdTRUE,
            pdFALSE,
            pdMS_TO_TICKS(1000)
        );
        if((uxBits & EVENT_SPI_RX_DATA) != 0)
        {
            while(xQueueReceive(xSpiRxQueue, &rxData, 0) == pdTRUE)
            {
                rxData.recvTimestamp = (uint32_t)(xTaskGetTickCount() * portTICK_PERIOD_MS);
                uint32_t roundTripTime = rxData.recvTimestamp - rxData.sendTimestamp;
                uint32_t canId = *(uint32_t *)rxData.data;
                LOG("================================================\r\n");
                LOG("SPI Round-trip time: %lu ms\r\n", roundTripTime);
                LOG("CAN ID:0x%03lX | 64字节SPI完整接收数据:\r\n", canId);
                for (uint8_t i = 0; i < SPI_FRAME_SIZE; i++)
                {
                    LOG("%02X ", rxData.data[i]);
                    if((i+1) % 16 == 0) LOG("\r\n");
                }
                LOG("\r\n================================================\r\n\r\n");
                PINS_DRV_TogglePins(LED_PORT, (1 << LED0));

                // SPI→CAN1转发核心调用
                ProcessAndForwardSPI2CANData(&rxData);
                xEventGroupSetBits(xSystemEvents, EVENT_SPI2CAN_READY);
            }
        }
        else
        {
            static uint32_t timeout_count = 0;
            timeout_count++;
            if (timeout_count % 10 == 0)
            {
                LOG("SPI Rx: 等待从机响应... (超时计数: %lu)\r\n", timeout_count);
            }
        }
        Watchdog_Pet(WD_SPI_RX);
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}
/******************************************************************************
 * SPI→CAN1数据处理函数（64字节直接转发）
 ******************************************************************************/
void ProcessAndForwardSPI2CANData(SpiRxData *spiRxData)
{
    flexcan_msgbuff_t forwardMsg;
    // CAN FD消息配置：固定ID 0x300，长度64字节
    forwardMsg.msgId = CANFD_TX_FORWARD_ID;
    forwardMsg.dataLen = CANFD_MAX_DLEN;
    // 直接复制SPI接收的64字节数据
    memcpy(forwardMsg.data, spiRxData->data, SPI_FRAME_SIZE);
    // 打印转发日志
    LOG("SPI→CAN1转发: 固定ID=0x%03lX 数据长度=64字节\r\n", CANFD_TX_FORWARD_ID);
    // 推入CAN1发送队列
    if (xQueueSend(xCan1TxQueue, &forwardMsg, pdMS_TO_TICKS(100)) != pdPASS) {
        LOG("警告: CAN1发送队列已满\r\n");
    }
}
/******************************************************************************
 * CAN1 CAN FD发送任务（含看门狗喂狗+重试机制）
 ******************************************************************************/
void CAN1_Tx_Task(void *pvParameters)
{
    flexcan_msgbuff_t txMsg;
    (void)pvParameters;
    xEventGroupWaitBits(xSystemEvents, EVENT_FUNC_STARTED, pdFALSE, pdFALSE, portMAX_DELAY);
    LOG("CAN1 CAN FD发送任务启动成功 - 支持64字节发送\r\n");
    /* 任务循环：喂看门狗（WD_CAN1_TX） */
    for(;;)
    {
        if(xQueueReceive(xCan1TxQueue, &txMsg, pdMS_TO_TICKS(100)) == pdTRUE)
        {
            if(xSemaphoreTake(xCan1Mutex, pdMS_TO_TICKS(100)) == pdTRUE)
            {
                // CAN FD模式核心配置
                flexcan_data_info_t fd_dataInfo = {
                    .data_length = txMsg.dataLen,      // 64字节
                    .msg_id_type = FLEXCAN_MSG_ID_STD,
                    .enable_brs  = true,               // 启用波特率切换
                    .fd_enable   = true,               // 开启CAN FD模式
                    .fd_padding  = 0U
                };
                // 3次重试机制
                uint8_t retry_count = 0;
                status_t send_status = STATUS_ERROR;
                while (retry_count < 3 && send_status != STATUS_SUCCESS)
                {
                    FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1, CAN1_TX_MAILBOX, &fd_dataInfo, txMsg.msgId);
                    send_status = FLEXCAN_DRV_Send(INST_CANCOM1, CAN1_TX_MAILBOX, &fd_dataInfo, txMsg.msgId, txMsg.data);
                    if (send_status != STATUS_SUCCESS)
                    {
                        retry_count++;
                        vTaskDelay(pdMS_TO_TICKS(5));
                    }
                }
                if(send_status == STATUS_SUCCESS)
                {
                    LOG("CAN1发送成功: ID=0x%03lX 长度=%d字节\r\n", txMsg.msgId, txMsg.dataLen);
                    PINS_DRV_TogglePins(LED_PORT, (1 << LED2)); // LED2闪烁指示
                }
                else
                {
                    LOG("CAN1发送失败: ID=0x%03lX 重试次数=%d\r\n", txMsg.msgId, retry_count);
                }
                xSemaphoreGive(xCan1Mutex);
            }
        }
        // 队列剩余空间检查
        UBaseType_t queue_spaces = uxQueueSpacesAvailable(xCan1TxQueue);
        if (queue_spaces < 10)
        {
            LOG("警告: CAN1发送队列剩余空间不足: %lu\r\n", queue_spaces);
        }
        Watchdog_Pet(WD_CAN1_TX);
        vTaskDelay(pdMS_TO_TICKS(2));
    }
}
/******************************************************************************
 * UART任务（含看门狗喂狗）
 ******************************************************************************/
void UART_Task(void *pvParameters)
{
    flexcan_msgbuff_t uartMsg;
    EventBits_t uxBits;
    (void)pvParameters;
    UART_ReceiveData(&uart_pal1_instance, uartRxBuffer, 1U);
    LOG("UART任务启动成功 - 支持回显和CAN数据打印\r\n");
    /* 任务循环：喂看门狗（WD_UART） */
    for(;;)
    {
        const TickType_t xMaxBlockTime = pdMS_TO_TICKS(500);
        uxBits = xEventGroupWaitBits(
            xSystemEvents,
            EVENT_CAN_DATA_RECEIVED | EVENT_UART_TX_READY,
            pdTRUE,
            pdFALSE,
            xMaxBlockTime
        );
        if((uxBits & EVENT_CAN_DATA_RECEIVED) != 0)
        {
            if(xQueueReceive(xCanRxQueue, &uartMsg, 0) == pdTRUE)
            {
                if(uartMsg.dataLen > 0 && uartMsg.data[0] == 0x01)
                {
                    PINS_DRV_TogglePins(LED_PORT, (1 << LED1));
                }
            }
        }
        if((uxBits & EVENT_UART_TX_READY) != 0 && rxComplete)
        {
            uartRxBuffer[bufferIdx] = '\0';
            if(xSemaphoreTake(xUartMutex, pdMS_TO_TICKS(10)) == pdTRUE)
            {
                UART_SendDataBlocking(&uart_pal1_instance, (uint8_t*)"Echo: ", 6, TIMEOUT);
                UART_SendDataBlocking(&uart_pal1_instance, uartRxBuffer, bufferIdx, TIMEOUT);
                UART_SendDataBlocking(&uart_pal1_instance, (uint8_t*)"\r\n", 2, TIMEOUT);
                xSemaphoreGive(xUartMutex);
            }
            bufferIdx = 0;
            rxComplete = false;
            UART_ReceiveData(&uart_pal1_instance, uartRxBuffer, 1U);
        }
        Watchdog_Pet(WD_UART);
        vTaskDelay(pdMS_TO_TICKS(1));
    }
}
/******************************************************************************
 * LED任务（含看门狗喂狗）
 ******************************************************************************/
void LED_Task(void *pvParameters)
{
    EventBits_t uxBits;
    (void)pvParameters;
    for(;;)
    {
        // LED2作为心跳灯，每500ms翻转一次（核心恢复点）
        PINS_DRV_TogglePins(LED_PORT, (1 << LED2));
        /* 喂看门狗 */
        Watchdog_Pet(WD_LED);
        vTaskDelay(pdMS_TO_TICKS(500));

        // 检测按键事件（EVENT_BUTTON1_PRESSED），触发LED1翻转
        uxBits = xEventGroupGetBits(xSystemEvents);
        if((uxBits & EVENT_BUTTON1_PRESSED) != 0)
        {
            xEventGroupClearBits(xSystemEvents, EVENT_BUTTON1_PRESSED);
            PINS_DRV_TogglePins(LED_PORT, (1 << LED1));
        }
    }
}
/******************************************************************************
 * 看门狗核心函数（原版完整实现）
 ******************************************************************************/
void Watchdog_Pet(WatchdogId_t id)
{
    if (id >= WD_COUNT) return;
    taskENTER_CRITICAL();
    g_watchdog_last_tick[id] = xTaskGetTickCount();
    taskEXIT_CRITICAL();
}
static void Watchdog_Task(void *pvParameters)
{
    (void)pvParameters;
    const TickType_t check_delay = pdMS_TO_TICKS(WATCHDOG_CHECK_MS);
    const TickType_t timeout_ticks = pdMS_TO_TICKS(WATCHDOG_TIMEOUT_MS);
    LOG("看门狗任务启动 - 监控所有%d个任务\r\n", WD_COUNT);
    /* 初始化所有任务时间戳 */
    static BaseType_t watchdog_initialized = pdFALSE;
    if (watchdog_initialized == pdFALSE)
    {
        taskENTER_CRITICAL();
        for (int k = 0; k < WD_COUNT; k++) g_watchdog_last_tick[k] = xTaskGetTickCount();
        taskEXIT_CRITICAL();
        watchdog_initialized = pdTRUE;
    }
    /* 看门狗循环检查 */
    for (;;)
    {
        vTaskDelay(check_delay);
        TickType_t now = xTaskGetTickCount();
        // 遍历监控所有任务
        for (int i = 0; i < WD_COUNT; i++)
        {
            TickType_t last;
            taskENTER_CRITICAL();
            last = g_watchdog_last_tick[i];
            taskEXIT_CRITICAL();
            // 计算已耗时（处理Tick溢出）
            TickType_t elapsed;
            if (now >= last)
                elapsed = now - last;
            else
                elapsed = (0xFFFFFFFF - last) + now;
            // 超时处理
            if(elapsed > timeout_ticks)
            {
                const char *task_names[WD_COUNT] = {
                    "CAN_Init", "SPI_Init", "UART", "LED",
                    "CAN2_Rx", "SPI_Tx", "SPI_Rx", "CAN1_Tx"
                };
                LOG("看门狗超时: 任务 [%s] | 耗时: %lu 嘀嗒\r\n", task_names[i], elapsed);
                // 重置该任务计时器
                taskENTER_CRITICAL();
                g_watchdog_last_tick[i] = now;
                taskEXIT_CRITICAL();
                LOG("任务 [%s] 计时器已重置\r\n", task_names[i]);
            }
        }
    }
}
/******************************************************************************
 * 辅助函数（保留）
 ******************************************************************************/
void UART_PrintCANMsg(uint32_t msgId, uint8_t *data, uint8_t len)
{
    char buf[64];
    int pos = 0;
    pos += sprintf(buf + pos, "CAN接收: ID=0x%03lX | 数据:", msgId);
    for (uint8_t i = 0; i < len && pos < (int)sizeof(buf) - 4; i++)
    {
        pos += sprintf(buf + pos, "%02X ", data[i]);
    }
    pos += sprintf(buf + pos, "\r\n");
    if (xUartMutex != NULL && xSemaphoreTake(xUartMutex, pdMS_TO_TICKS(10)) == pdTRUE)
    {
        UART_SendDataBlocking(&uart_pal1_instance, (uint8_t*)buf, (uint32_t)pos, TIMEOUT);
        xSemaphoreGive(xUartMutex);
    }
    else
    {
        UART_SendDataBlocking(&uart_pal1_instance, (uint8_t*)buf, (uint32_t)pos, TIMEOUT);
    }
}
/******************************************************************************
 * LED控制（恢复参考文档逻辑：仅控制LED，不打印额外日志）
 ******************************************************************************/
void LED_ControlByCAN(uint32_t msgId, uint8_t *data, uint8_t dataLen)
{
    switch (msgId) {
        case CAN_LED_CTRL_ID_LED0_ON:
            PINS_DRV_SetPins(LED_PORT, 1UL << LED0);
            return;  // 匹配参考文档，直接返回不打印
        case CAN_LED_CTRL_ID_LED1_ON:
            PINS_DRV_SetPins(LED_PORT, 1UL << LED1);
            return;  // 匹配参考文档，直接返回不打印
        default: break;
    }
    if (dataLen > 0) {
        switch (data[0]) {
            case CAN_LED_CTRL_DATA_TOGGLE:
                PINS_DRV_TogglePins(LED_PORT, (1UL << LED0) | (1UL << LED1));
                break;
            case CAN_LED_CTRL_DATA_OFF:
                PINS_DRV_ClearPins(LED_PORT, (1UL << LED0) | (1UL << LED1));
                break;
            case CAN_LED_CTRL_DATA_ON:
                PINS_DRV_SetPins(LED_PORT, (1UL << LED0) | (1UL << LED1));
                break;
            default:
                PINS_DRV_TogglePins(LED_PORT, 1UL << LED0);
                break;
        }
    }
}
void SPI_SendCANMessage(uint32_t msgId, uint8_t *data, uint8_t dataLen)
{
    flexcan_msgbuff_t spiMsg;
    spiMsg.msgId = msgId;
    spiMsg.dataLen = dataLen;
    memcpy(spiMsg.data, data, dataLen);
    if (xSpiTxQueue != NULL)
    {
        if (xQueueSend(xSpiTxQueue, &spiMsg, 0) != pdPASS)
        {
            LOG("SPI队列满: 丢弃CAN消息 0x%03lX\r\n", msgId);
        }
        else
        {
            LOG("CAN→SPI: 消息 0x%03lX 已加入SPI发送队列\r\n", msgId);
        }
    }
}
void uart_log(const char *fmt, ...)
{
    char buf[256];
    va_list args;
    va_start(args, fmt);
    int len = vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    if (len <= 0) return;
    if (len > (int)sizeof(buf)) len = (int)sizeof(buf);
    if (xTaskGetSchedulerState() == taskSCHEDULER_NOT_STARTED)
    {
        printf("%s", buf);
        return;
    }
    if (xUartMutex != NULL && xSemaphoreTake(xUartMutex, pdMS_TO_TICKS(20)) == pdTRUE)
    {
        UART_SendDataBlocking(&uart_pal1_instance, (uint8_t*)buf, (uint32_t)len, TIMEOUT);
        xSemaphoreGive(xUartMutex);
        return;
    }
    UART_SendDataBlocking(&uart_pal1_instance, (uint8_t*)buf, (uint32_t)len, TIMEOUT);
}
void CANCOM1_Init(void)
{
    LOG("CANCOM1 初始化（CAN FD模式）...\r\n");
    status_t status = FLEXCAN_DRV_Init(INST_CANCOM1, &canCom1_State, &canCom1_InitConfig0);
    if (status == STATUS_SUCCESS) {
        LOG("CANCOM1 初始化成功（CAN FD模式）\r\n");
        LOG("  支持CAN FD，最大64字节数据长度\r\n");
    } else {
        LOG("CANCOM1 初始化失败（状态: %d）\r\n", status);
    }
}
void CANCOM2_Init(void)
{
    LOG("CANCOM2 初始化（标准CAN模式）...\r\n");
    status_t status = FLEXCAN_DRV_Init(INST_CANCOM2, &canCom2_State, &canCom2_InitConfig0);
    if (status == STATUS_SUCCESS) {
        LOG("CANCOM2 初始化成功（标准CAN模式）\r\n");
        LOG("  支持标准CAN，最大8字节数据长度\r\n");
    } else {
        LOG("CANCOM2 初始化失败（状态: %d）\r\n", status);
    }
}
void DSPI_Init(void)
{
    LOG("DSPI 初始化（主机模式）...\r\n");
    dspi_master_config_t spi_config;
    status_t status = DSPI_GetDefaultMasterCfg(&spi_config);
    if (status != STATUS_SUCCESS)
    {
        LOG("DSPI 获取默认配置失败! 状态: %d\r\n", status);
        return;
    }
    spi_config.bitsPerSec = 1000000U;
    spi_config.pcsPolarity = DSPI_ACTIVE_LOW;
    spi_config.clkPhase = DSPI_CLOCK_PHASE_1ST_EDGE;
    spi_config.clkPolarity = DSPI_ACTIVE_HIGH;
    status = DSPI_MasterInit(INST_DSPI1, &dspi1State, &spi_config);
    if (status != STATUS_SUCCESS)
    {
        LOG("DSPI 主机初始化失败! 状态: %d\r\n", status);
    }
    else
    {
        LOG("DSPI 初始化成功\r\n");
        LOG("  SPI配置: 1MHz, Mode0(CPOL=0, CPHA=0), 主机模式\r\n");
    }
}
void Board_Init(void)
{
    CLOCK_SYS_Init(g_clockManConfigsArr, CLOCK_MANAGER_CONFIG_CNT,
                   g_clockManCallbacksArr, CLOCK_MANAGER_CALLBACK_CNT);
    CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_FORCIBLE);
    PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr);
}
void GPIO_Init(void)
{
    PINS_DRV_ClearPins(LED_PORT, (1 << LED0) | (1 << LED1));
    PINS_DRV_SetPins(LED_PORT, (1 << LED2));
}
/******************************************************************************
 * RTOS基础对象初始化（含看门狗任务创建，优先级最高）
 ******************************************************************************/
void RTOS_Objects_Init_Base(void)
{
    /* 创建核心RTOS对象 */
    xSystemEvents = xEventGroupCreate();
    xUartMutex = xSemaphoreCreateMutex();
    xCanMutex = xSemaphoreCreateMutex();
    xSpiMutex = xSemaphoreCreateMutex();
    xCan1Mutex = xSemaphoreCreateMutex();

    /* 断言检查 */
    configASSERT(xSystemEvents != NULL);
    configASSERT(xUartMutex != NULL);
    configASSERT(xCanMutex != NULL);
    configASSERT(xSpiMutex != NULL);
    configASSERT(xCan1Mutex != NULL);

    /* 创建看门狗任务（优先级最高：configMAX_PRIORITIES - 1） */
    BaseType_t wd_task_status = xTaskCreate(Watchdog_Task, "Watchdog", 256, NULL, configMAX_PRIORITIES - 1, NULL);
    configASSERT(wd_task_status == pdPASS);
    LOG("RTOS基础对象初始化完成 - 含看门狗+CAN1互斥锁\r\n");
}
/******************************************************************************
 * RTOS功能对象初始化（含CAN1队列+任务）
 ******************************************************************************/
void RTOS_Objects_Init_Func(void)
{
    LOG("开始创建所有功能对象 - 队列 + CAN/SPI传输任务\r\n");
    /* 创建队列 */
    xCanRxQueue = xQueueCreate(5, sizeof(flexcan_msgbuff_t));
    xSpiTxQueue = xQueueCreate(10, sizeof(flexcan_msgbuff_t));
    xSpiRxQueue = xQueueCreate(5, sizeof(SpiRxData));
    xCan1TxQueue = xQueueCreate(50, sizeof(flexcan_msgbuff_t));

    /* 断言检查 */
    configASSERT(xCanRxQueue != NULL);
    configASSERT(xSpiTxQueue != NULL);
    configASSERT(xSpiRxQueue != NULL);
    configASSERT(xCan1TxQueue != NULL);

    /* 创建任务（CAN1_Tx栈设为512，解决内存不足问题） */
    BaseType_t taskCreateStatus;
    taskCreateStatus = xTaskCreate(CAN2_Rx_Task, "CAN2_Rx", 512, NULL, 3, &xCan2RxTaskHandle);
    configASSERT(taskCreateStatus == pdPASS);
    taskCreateStatus = xTaskCreate(SPI_Tx_Task, "SPI_Tx", 256, NULL, 3, &xSpiTxTaskHandle);
    configASSERT(taskCreateStatus == pdPASS);
    taskCreateStatus = xTaskCreate(SPI_Rx_Task, "SPI_Rx", 256, NULL, 3, &xSpiRxTaskHandle);
    configASSERT(taskCreateStatus == pdPASS);
    taskCreateStatus = xTaskCreate(CAN1_Tx_Task, "CAN1_Tx", 512, NULL, 2, &xCan1TxTaskHandle);
    configASSERT(taskCreateStatus == pdPASS);

    xEventGroupSetBits(xSystemEvents, EVENT_FUNC_STARTED);
    LOG("所有功能对象创建完成 - 含CAN1 CAN FD发送任务\r\n");
}
/******************************************************************************
 * 主函数（完整保留）
 ******************************************************************************/
volatile int exit_code = 0;
int main(void)
{
#ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();
#endif
    srand(0x1234);
    /* 硬件底层初始化 */
    Board_Init();
    GPIO_Init();
    UART_Init(&uart_pal1_instance, &uart_pal1_Config0);
    UART_ReceiveData(&uart_pal1_instance, uartRxBuffer, 1U);

    /* 打印启动信息 */
    LOG("\r\n");
    LOG("================================================\r\n");
    LOG("多外设系统启动（最终完整版：含看门狗+CAN FD转发）\r\n");
    LOG("核心功能：CAN2→SPI + SPI→CAN1 64字节转发 + 8任务看门狗监控\r\n");
    LOG("系统编译时间: %s %s\r\n", __DATE__, __TIME__);
    LOG("================================================\r\n");

    /* RTOS基础对象初始化（含看门狗） */
    RTOS_Objects_Init_Base();

    /* 创建基础任务 */
    xTaskCreate(CAN_Init_Task, "CAN Init", 512, NULL, 3, &xCanInitTaskHandle);
    xTaskCreate(SPI_Init_Task, "SPI Init", 384, NULL, 3, &xSpiInitTaskHandle);
    xTaskCreate(UART_Task, "UART", 256, NULL, 2, &xUartTaskHandle);
    xTaskCreate(LED_Task, "LED", 128, NULL, 1, &xLedTaskHandle);

    /* 启动FreeRTOS调度器 */
    LOG("启动FreeRTOS调度器...\r\n");
    vTaskStartScheduler();

    /* 调度器启动失败：LED全闪报警 */
    LOG("调度器启动失败!\r\n");
    for(;;)
    {
        PINS_DRV_TogglePins(LED_PORT, (1 << LED0) | (1 << LED1) | (1 << LED2));
        volatile uint32_t i;
        for(i = 0; i < 500000; i++);
    }
    return exit_code;
}
